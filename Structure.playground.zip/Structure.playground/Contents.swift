import UIKit

struct Engine {
    var v6: Int
    var car: String
    var version: Int
}
var Collect : [String] = ["mustang", "Diamond" ]
print("You have \(Collect.count) cars")
if Collect.isEmpty {
    print("You have no cars")
} else {
    print("cars in inventory")
}

var Engine2 = Engine( v6:6, car:"Diamond", version: 8)

print("The versions of engine is \(Engine2.version)")
print("The type of car that has a V6 \(Engine2.car)")
print("The engine is \(Engine2.v6)")
